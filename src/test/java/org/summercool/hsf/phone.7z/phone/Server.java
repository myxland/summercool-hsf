package org.summercool.hsf.test.phone;

import org.summercool.hsf.netty.decoder.LengthBasedDecoder;
import org.summercool.hsf.netty.encoder.LengthBasedEncoder;
import org.summercool.hsf.netty.handler.downstream.SerializeDownstreamHandler;
import org.summercool.hsf.netty.handler.upstream.DeserializeUpstreamHandler;
import org.summercool.hsf.netty.service.HsfAcceptor;
import org.summercool.hsf.netty.service.HsfAcceptorImpl;
import org.summercool.hsf.util.HsfOptions;

/**
 * @Title: Server.java
 * @Package org.summercool.hsf.test.phone
 * @date 2012-3-19 下午10:48:42
 * @version V1.0
 */
public class Server {
	public static void main(String[] args) {
		HsfAcceptor acceptor = new HsfAcceptorImpl();
		acceptor.setOption(HsfOptions.HANDSHAKE_TIMEOUT, 6000000);
		acceptor.setOption(HsfOptions.READ_IDLE_TIME, 6000000);
		// clear
		acceptor.getHandlers().clear();
		//
		PhoneSerializer serializer = new PhoneSerializer();

		acceptor.getHandlers().put("encode", new LengthBasedEncoder());
		acceptor.getHandlers().put("serialize", new SerializeDownstreamHandler(serializer));

		acceptor.getHandlers().put("decode", new LengthBasedDecoder());
		acceptor.getHandlers().put("deserialize", new DeserializeUpstreamHandler(serializer));

		acceptor.registerService(new PhoneServiceImpl());
		acceptor.bind(8088);
	}
}
