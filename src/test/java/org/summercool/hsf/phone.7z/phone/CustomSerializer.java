package org.summercool.hsf.test.phone;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBufferFactory;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.buffer.HeapChannelBufferFactory;
import org.summercool.hsf.serializer.Serializer;

/**
 * @Title: CustomSerializer.java
 * @Package org.summercool.hsf.test.phone
 * @Description: 自定义序列化类
 * @date 2012-3-23 下午11:18:03
 * @version V1.0
 */
public class CustomSerializer implements Serializer {
	public static final byte[] HEARTBEAT_BYTES = new byte[4];
	public static final byte[] EMPTY_BYTES = new byte[0];
	private static ChannelBufferFactory bufferFactory = HeapChannelBufferFactory.getInstance();

	@Override
	public void init() throws Exception {
	}

	@Override
	public byte[] serialize(Object object) throws Exception {
		if (object == null) {
			throw new NullPointerException();
		} else if (!(object instanceof byte[])) {
			throw new IllegalArgumentException("msg required byte[]");
		}
		//
		byte[] msg = (byte[]) object;
		ChannelBuffer buffer = ChannelBuffers.dynamicBuffer(msg.length + 4, bufferFactory);
		buffer.writeInt(msg.length);
		buffer.writeBytes(msg);
		
		byte[] result = new byte[msg.length + 4];
		buffer.readBytes(result);

		return result;
	}

	@Override
	public Object deserialize(byte[] bytes) throws Exception {
		if (bytes == null) {
			throw new NullPointerException();
		}
		//
		ChannelBuffer buffer = ChannelBuffers.dynamicBuffer(bytes.length, bufferFactory);
		buffer.writeBytes(bytes);
		//
		int length = buffer.readInt();
		if (bytes.length != length + 4) {
			throw new IllegalArgumentException();
		}
		//
		byte[] msg = new byte[length];
		buffer.readBytes(msg);
		
		return msg;
	}

	@Override
	public void register(Class<?> class1) {
	}

}
