package org.summercool.hsf.test.phone;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBufferFactory;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.buffer.HeapChannelBufferFactory;
import org.summercool.hsf.pojo.HandshakeAck;
import org.summercool.hsf.pojo.HandshakeFinish;
import org.summercool.hsf.pojo.HandshakeRequest;
import org.summercool.hsf.pojo.RemoteServiceObject;
import org.summercool.hsf.pojo.RequestObject;
import org.summercool.hsf.pojo.ResponseObject;
import org.summercool.hsf.util.LangUtil;
import org.summercool.hsf.util.UUIDUtil;

public class PhoneClient {
	public static final String DEFAULT_CHARSET = "UTF-8";
	private static ChannelBufferFactory bufferFactory = HeapChannelBufferFactory.getInstance(ByteOrder.BIG_ENDIAN);
	private static PhoneSerializer phoneSerializer = new PhoneSerializer();
	private static ConcurrentHashMap<SocketChannel, ClientItem> map = new ConcurrentHashMap<SocketChannel, ClientItem>();
	private static AtomicLong seq = new AtomicLong();
	private static int workerCount = Runtime.getRuntime().availableProcessors() * 2;
	private static ExecutorService workerPool = Executors.newFixedThreadPool(workerCount);
	private static ExecutorService schedulerPool = Executors.newFixedThreadPool(100);
	private static ExecutorService processPool = Executors.newCachedThreadPool();
	private static SelectorItem[] selectorArray = new SelectorItem[workerCount];
	private static AtomicInteger selectorIndex = new AtomicInteger();

	private ByteBuffer sendBuffer = ByteBuffer.allocate(1024).order(ByteOrder.BIG_ENDIAN);
	private ByteBuffer receivedBuffer = ByteBuffer.allocate(1024).order(ByteOrder.BIG_ENDIAN);
	private SelectorItem selector;
	private SocketChannel socketChannel = null;
	private String groupName;

	static {
		// 创建Selector池
		try {
			for (int i = 0; i < workerCount; i++) {
				Selector selector = Selector.open();
				selectorArray[i] = new SelectorItem(selector);
				workerPool.execute(new NioWorker(selectorArray[i]));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public PhoneClient(String ip, int port) throws Exception {
		// 建立连接
		socketChannel = SocketChannel.open();
		InetSocketAddress isa = new InetSocketAddress(ip, port);
		socketChannel.connect(isa);
		socketChannel.configureBlocking(false);

		// 缓存当前连接的信息
		groupName = "java nio client " + seq.incrementAndGet();
		ClientItem item = new ClientItem();
		item.setGroupName(groupName);
		item.setReceivedBuffer(receivedBuffer);
		item.setSendBuffer(sendBuffer);

		map.put(socketChannel, item);
		// 生成握手请求消息包，并放入sendBuffer中
		byte[] bytes = getHandshakeRequestBytes();
		sendBuffer.put(bytes);
		sendBuffer.slice();

		// 注册到selector
		selector = getNextSelector();
		socketChannel.register(selector.getSelector(), SelectionKey.OP_READ | SelectionKey.OP_WRITE);
		// 释放
		selector.getSemaphore().release();
	}

	/**
	 * 模拟远程调用消息
	 */
	private static ByteBuffer getMsg() throws Exception {
		// 构建远程调用实体（包含接口名称、方法及参数）
		RemoteServiceObject remoteServiceObj = new RemoteServiceObject();
		remoteServiceObj.setServiceName(PhoneService.class.getSimpleName());
		remoteServiceObj.setMethodName("doExecute");
		remoteServiceObj.setArgs(new Object[] { encode(UUIDUtil.random()) });

		// 构建请求消息实体，其中seq字段用以关联request和response消息，target为真正的消息实体
		RequestObject request = new RequestObject();
		request.setSeq(seq.incrementAndGet());
		request.setTarget(remoteServiceObj);

		// 编码
		ChannelBuffer ob = ChannelBuffers.dynamicBuffer(512, bufferFactory);
		byte[] bytes = phoneSerializer.serialize(request);
		ob.writeInt(bytes.length);
		ob.writeBytes(bytes);

		ByteBuffer buffer = ob.toByteBuffer();
		return buffer;
	}

	/**
	 * 获取下一个Selector
	 */
	private SelectorItem getNextSelector() {
		int index = selectorIndex.getAndIncrement() % workerCount;
		return selectorArray[index];
	}

	/**
	 * 获取有效数据
	 */
	private static byte[] getBuffer(ChannelBuffer ob) {
		byte[] buffer = new byte[ob.readableBytes()];
		ob.readBytes(buffer);
		return buffer;
	}

	/**
	 * 获取握手请求消息包
	 */
	private byte[] getHandshakeRequestBytes() throws Exception {
		HandshakeRequest request = new HandshakeRequest(groupName);
		//
		ChannelBuffer ob = ChannelBuffers.dynamicBuffer(512, bufferFactory);
		byte[] bytes = phoneSerializer.serialize(request);
		ob.writeInt(bytes.length);
		ob.writeBytes(bytes);

		return getBuffer(ob);
	}

	/**
	 * 发送消息
	 */
	public void sendMsg() throws Exception {
		socketChannel.write(getMsg());
	}

	/**
	 * 发送sendBuffer中的消息
	 */
	public static void send(SelectionKey key) throws IOException {
		SocketChannel socketChannel = (SocketChannel) key.channel();
		ByteBuffer sendBuffer = map.get(socketChannel).getSendBuffer();
		if (sendBuffer.remaining() > 0 && sendBuffer.position() > 0) {
			synchronized (sendBuffer) {
				sendBuffer.flip();
				socketChannel.write(sendBuffer);
				sendBuffer.compact();
			}
		}
	}

	/**
	 * 接收消息
	 */
	public static void receive(SelectionKey key) throws Exception {
		SocketChannel socketChannel = (SocketChannel) key.channel();
		//
		ByteBuffer receivedBuffer = map.get(socketChannel).getReceivedBuffer();
		String groupName = map.get(socketChannel).getGroupName();
		// 读取消息
		int readNum = socketChannel.read(receivedBuffer);
		receivedBuffer.flip();

		if (readNum >= 4) {
			receivedBuffer.mark();
			int length = receivedBuffer.getInt();
			if (length == 0) {
				return;
			}

			if (receivedBuffer.remaining() < length) {
				receivedBuffer.reset();
				return;
			}
			// 读取消息內容
			byte[] dst = new byte[length];
			receivedBuffer.get(dst);

			// 返序列化返回值
			Object retValue = phoneSerializer.deserialize(dst);
			// 如果接收到Server发送的握手反馈消息，则回送握手完成消息
			if (retValue instanceof HandshakeAck) {
				//
				ChannelBuffer ob = ChannelBuffers.dynamicBuffer(512, bufferFactory);
				try {
					// 构造握手完成消息包
					HandshakeFinish finish = new HandshakeFinish(groupName);
					byte[] bytes = phoneSerializer.serialize(finish);
					// 长度
					ob.writeInt(bytes.length);
					// 消息内容
					ob.writeBytes(bytes);
					// 发送消息
					socketChannel.write(ob.toByteBuffer());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			// Service调用的返回对象
			else if (retValue instanceof ResponseObject) {
				// 获取Service调用返回值
				ResponseObject resObj = (ResponseObject) retValue;
				byte[] retBuffer = (byte[]) resObj.getTarget();
				System.out.println(decode(retBuffer));
			} else {
				// 其它消息，如心跳
				// System.out.println("received msg:" + retValue);
			}
		}

		receivedBuffer.compact();
	}

	private static byte[] encode(String msg) throws UnsupportedEncodingException {
		if (msg == null) {
			return null;
		}
		return msg.getBytes(DEFAULT_CHARSET);
	}

	private static String decode(byte[] bytes) throws UnsupportedEncodingException {
		if (bytes == null) {
			return null;
		}
		return new String(bytes, DEFAULT_CHARSET);
	}

	/**
	 * 通道读写任务
	 */
	private static class NioWorker implements Runnable {
		private SelectorItem selectorItem;

		public NioWorker(SelectorItem selectorItem) {
			this.selectorItem = selectorItem;
		}

		@Override
		public void run() {
			// 如果未准备好，则阻塞
			try {
				selectorItem.getSemaphore().acquire();
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			while (true) {
				try {
					if (selectorItem.getSelector().select() > 0) {
						Set<SelectionKey> readyKeys = selectorItem.getSelector().selectedKeys();
						Iterator<SelectionKey> it = readyKeys.iterator();
						while (it.hasNext()) {
							final SelectionKey key = it.next();
							try {
								it.remove();
								// 读
								if (key.isReadable()) {
									processPool.execute(new Runnable() {

										@Override
										public void run() {
											try {
												receive(key);
											} catch (Exception e) {
												e.printStackTrace();
											}
										}
									});
								}
								// 写
								if (key.isWritable()) {
									send(key);
								}
							} catch (Exception e) {
								e.printStackTrace();
								try {
									if (key != null) {
										key.cancel();
										key.channel().close();
									}
								} catch (Exception ex) {
									e.printStackTrace();
								}
							}
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static class SelectorItem {
		private Selector selector;
		private Semaphore semaphore = new Semaphore(0);

		public SelectorItem(Selector selector) {
			this.selector = selector;
		}

		public Selector getSelector() {
			return selector;
		}

		public Semaphore getSemaphore() {
			return semaphore;
		}
	}

	private class ClientItem {
		private ByteBuffer sendBuffer;
		private ByteBuffer receivedBuffer;
		private String groupName;

		public ByteBuffer getSendBuffer() {
			return sendBuffer;
		}

		public void setSendBuffer(ByteBuffer sendBuffer) {
			this.sendBuffer = sendBuffer;
		}

		public ByteBuffer getReceivedBuffer() {
			return receivedBuffer;
		}

		public void setReceivedBuffer(ByteBuffer receivedBuffer) {
			this.receivedBuffer = receivedBuffer;
		}

		public String getGroupName() {
			return groupName;
		}

		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}

	}

	public static void main(String args[]) throws Exception {
		System.out.println(getMsg());
		
		final List<PhoneClient> list = new ArrayList<PhoneClient>();
		// 定时发送消息任务（调用远程服务）
		Executors.newScheduledThreadPool(1).scheduleAtFixedRate(new Runnable() {

			@Override
			public void run() {
				List<PhoneClient> copyList = new ArrayList<PhoneClient>(list);
				for (final PhoneClient phoneClient : copyList) {
					schedulerPool.execute(new Runnable() {

						@Override
						public void run() {
							try {
								for (int i = 0; i< 3; i++) {
									phoneClient.sendMsg();
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});
				}
			}
		}, 10000L, 1000L, TimeUnit.MILLISECONDS);

		// 解析参数
		String ip = "127.0.0.1";
		int port = 8088;
		int count = 10;
		if (args.length == 3) {
			ip = args[0];
			port = LangUtil.parseInt(args[1]);
			count = LangUtil.parseInt(args[2]);
		}

		System.out.println("client runs with args(ip:" + ip + ", port:" + port + ", count:" + count + ").");
		Thread.sleep(2000L);

		// 建立连接
		for (int i = 1; i <= count; ++i) {
			try {
				PhoneClient client = new PhoneClient(ip, port);
				list.add(client);
				System.out.println(i);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
